from __future__ import unicode_literals
# -* - coding: UTF-8 -* -
import configparser


def getConfig(section):
    config = configparser.ConfigParser()
    config.read("data/config.ini", encoding='utf-8')
    return dict(config.items(section))


priceConfig = getConfig("price_line")


def getPriceConfig():
    return priceConfig


sysConfig = getConfig("system")


def getSysConfig():
    return sysConfig

