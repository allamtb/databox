from user_agent import generate_user_agent


for i in range(100):
    print(generate_user_agent())