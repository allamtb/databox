class Pet:

    # 宠物编号
    pet_id = ""
    # 宠物昵称
    name = ''
    # 背景颜色
    bg_color = ''
    # 宠物代
    generation = 0
    # 稀有度
    rare_degree = 0
    # 出生类型
    birth_type = 0
    # 宠物类型
    pet_type = 0
    # 价格
    amount = 0
    # 变异
    mutation = 0
    # 验证码
    valid_Code = ""
    # 图片
    pet_url = ""
    # 交易ID
    id = ""


    ###############
    # 莱特狗具体属性#
    ###############
    #体型
    body_rare = 0
    body_desc = '刀刀耳'
    # 身体色
    body_color_rare = 0
    body_color_desc = '米色'
    # 花纹
    stripe_rare = 0
    stripe_desc = '散羽纹'
    # 花纹色
    stripe_color_rare = 0
    stripe_color_desc = '月灰'
    #眼睛
    eye_rare = 0
    eye_desc = '黑老大'
    #眼睛颜色
    eye_color_rare =0
    eye_color_desc = '黄绿'
    #嘴巴
    mouth_rare = 0
    mouth_desc = '北极熊'
    #肚皮色
    belly_color_rare = 0
    belly_color_desc = '烟粉'







