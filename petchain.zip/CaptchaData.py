import requests
import base64
import json


def get_captcha():
    r = {"code": 400}
    try:
        data = {
            "requestId": 1518007015081,
            "appId": 1,
            "tpl": ""
        }
        page = requests.post("https://pet-chain.baidu.com/data/captcha/gen", data=json.dumps(data), headers=headers)
        resp = page.json()
        if resp.get(u"errorMsg") == u"success":
            seed = resp.get(u"data").get(u"seed")
            img = resp.get(u"data").get(u"img")
            with open('data/captcha.jpg', 'wb') as file:
                file.write(base64.b64decode(img))
                file.close()
    except Exception as e:
        pass
